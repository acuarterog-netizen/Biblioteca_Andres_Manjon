echo url="https://www.duckdns.org/update?domains=TU_DOMINIO&token=TU_TOKEN&ip=" | curl -k -o /home/tu_usuario/duckdns/duck.log -K -

